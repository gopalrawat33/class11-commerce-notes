# Class 11 Commerce Notes — cross-platform web app

This is a responsive web app / PWA starter that can run on Android, iOS/iPadOS, Windows, macOS and Linux browsers.

## Try it locally
Open `index.html` in a browser to inspect the layout, but browser security may block JSON fetch from `file://`. For full operation, host the folder on an HTTPS static host.

## Make it fetch notes online
By default, `NOTES_URL` in `index.html` points to `./notes.json`. Host `index.html`, `manifest.json`, `sw.js`, `notes.json`, and `notes-fallback.json` together on a public HTTPS static host. To use a separate hosted JSON, replace `const NOTES_URL = "./notes.json";` with the full HTTPS raw JSON URL.
JSON shape:
{ "subjects": [ { "name": "Subject name", "chapters": [ { "title": "Chapter title", "notes": "Notes text" } ] } ] }

## Install
- Android: open the HTTPS website in Chrome and choose Install app / Add to Home screen (wording varies).
- iPhone/iPad: open in Safari, tap Share, then Add to Home Screen.
- Windows/macOS: use the browser's Install app option if offered, or bookmark the site.

## Important
- This is a starter version; it includes sample/template notes only, not all lessons.
- No hosting service or live database has been created for you by this ZIP.
- It is a web app, not a native App Store iOS app. Publishing a native iOS app requires Apple's developer workflow and review.
- Verify all lesson titles and answers against the current official Balbharati textbooks.
